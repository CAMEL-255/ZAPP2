import { supabase } from '../lib/supabase';
import { DataItem, DataType } from '../types';

class DataService {
  private generateNFCLink(dataItemId: string, type: DataType): string {
    const baseUrl = window.location.origin;
    return `${baseUrl}/nfc/${type}/${dataItemId}`;
  }

  async createDataItem(
    userId: string,
    deviceId: string,
    type: DataType,
    name: string,
    description?: string,
    fileData?: string,
    fileName?: string,
    fileType?: string,
    fileSize?: number
  ): Promise<DataItem> {
    try {
      // First, upload the file data if provided
      let photoUrl = null;
      if (fileData && fileName) {
        // Convert base64 to blob
        const response = await fetch(fileData);
        const blob = await response.blob();
        
        // Upload to Supabase Storage
        const fileExt = fileName.split('.').pop();
        const filePath = `${userId}/${Date.now()}.${fileExt}`;
        
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('photos')
          .upload(filePath, blob);

        if (uploadError) {
          console.error('File upload error:', uploadError);
        } else {
          // Get public URL
          const { data: { publicUrl } } = supabase.storage
            .from('photos')
            .getPublicUrl(filePath);
          photoUrl = publicUrl;
        }
      }

      // Create the data item record
      const { data, error } = await supabase
        .from('photos')
        .insert([
          {
            name,
            size: fileSize?.toString() || null,
            type: fileType || null,
            url: photoUrl,
            user_id: userId,
          }
        ])
        .select()
        .single();

      if (error) {
        throw error;
      }

      // Convert database record to DataItem format
      const dataItem: DataItem = {
        id: data.id.toString(),
        userId,
        deviceId,
        type,
        name,
        description,
        fileData: photoUrl || fileData,
        fileName,
        fileType,
        fileSize,
        nfcLink: this.generateNFCLink(data.id.toString(), type),
        createdAt: new Date(data.created_at),
        updatedAt: new Date(data.updated_at)
      };

      return dataItem;
    } catch (error) {
      console.error('Error creating data item:', error);
      throw error;
    }
  }

  async getDataItems(userId: string): Promise<DataItem[]> {
    try {
      const { data, error } = await supabase
        .from('photos')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (error) {
        throw error;
      }

      return data.map(item => ({
        id: item.id.toString(),
        userId,
        deviceId: '', // Not stored in current schema
        type: 'photo' as DataType, // Default type for now
        name: item.name || 'Untitled',
        description: undefined,
        fileData: item.url,
        fileName: item.name,
        fileType: item.type,
        fileSize: item.size ? parseInt(item.size) : undefined,
        nfcLink: this.generateNFCLink(item.id.toString(), 'photo'),
        createdAt: new Date(item.created_at),
        updatedAt: new Date(item.updated_at)
      }));
    } catch (error) {
      console.error('Error fetching data items:', error);
      return [];
    }
  }

  async getDataItemsByType(userId: string, type: DataType): Promise<DataItem[]> {
    const items = await this.getDataItems(userId);
    return items.filter(item => item.type === type);
  }

  async getDataItem(id: string): Promise<DataItem | null> {
    try {
      const { data, error } = await supabase
        .from('photos')
        .select('*')
        .eq('id', parseInt(id))
        .single();

      if (error || !data) {
        return null;
      }

      return {
        id: data.id.toString(),
        userId: data.user_id,
        deviceId: '',
        type: 'photo' as DataType,
        name: data.name || 'Untitled',
        description: undefined,
        fileData: data.url,
        fileName: data.name,
        fileType: data.type,
        fileSize: data.size ? parseInt(data.size) : undefined,
        nfcLink: this.generateNFCLink(data.id.toString(), 'photo'),
        createdAt: new Date(data.created_at),
        updatedAt: new Date(data.updated_at)
      };
    } catch (error) {
      console.error('Error fetching data item:', error);
      return null;
    }
  }

  async updateDataItem(id: string, updates: Partial<DataItem>): Promise<DataItem | null> {
    try {
      const { data, error } = await supabase
        .from('photos')
        .update({
          name: updates.name,
          updated_at: new Date().toISOString()
        })
        .eq('id', parseInt(id))
        .select()
        .single();

      if (error || !data) {
        return null;
      }

      return {
        id: data.id.toString(),
        userId: data.user_id,
        deviceId: '',
        type: 'photo' as DataType,
        name: data.name || 'Untitled',
        description: undefined,
        fileData: data.url,
        fileName: data.name,
        fileType: data.type,
        fileSize: data.size ? parseInt(data.size) : undefined,
        nfcLink: this.generateNFCLink(data.id.toString(), 'photo'),
        createdAt: new Date(data.created_at),
        updatedAt: new Date(data.updated_at)
      };
    } catch (error) {
      console.error('Error updating data item:', error);
      return null;
    }
  }

  async deleteDataItem(id: string): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('photos')
        .delete()
        .eq('id', parseInt(id));

      return !error;
    } catch (error) {
      console.error('Error deleting data item:', error);
      return false;
    }
  }

  async getDataItemByNFCLink(link: string): Promise<DataItem | null> {
    // Extract ID from NFC link
    const matches = link.match(/\/nfc\/[^\/]+\/(\d+)$/);
    if (!matches) return null;
    
    const id = matches[1];
    return this.getDataItem(id);
  }
}

export const dataService = new DataService();