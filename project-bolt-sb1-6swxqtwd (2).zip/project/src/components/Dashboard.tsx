import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useDevice } from '../context/DeviceContext';
import FileUpload from './FileUpload';
import DataManager from './DataManager';
import NFCManager from './NFCManager';
import { User, LogOut, Smartphone, Zap } from 'lucide-react';

const Dashboard: React.FC = () => {
  const { user, signOut } = useAuth();
  const { deviceId } = useDevice();
  const [activeTab, setActiveTab] = useState<'data' | 'upload' | 'nfc'>('data');

  return (
    <div className="min-h-screen p-4">
      {/* Header */}
      <div className="card p-4 mb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="bg-gradient-to-r from-purple-600 to-blue-600 w-10 h-10 rounded-full flex items-center justify-center">
              <Zap className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-800">ZButton Beta</h1>
              <p className="text-sm text-gray-600">Welcome back!</p>
            </div>
          </div>
          <button
            onClick={signOut}
            className="btn-secondary text-gray-700 border-gray-300 hover:bg-gray-50 p-2"
            title="Sign Out"
          >
            <LogOut className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* User Info */}
      <div className="card p-4 mb-6">
        <div className="space-y-3">
          <div className="flex items-center space-x-3">
            <User className="w-5 h-5 text-gray-600" />
            <div>
              <p className="text-sm text-gray-600">Account</p>
              <p className="font-medium text-gray-800">{user?.email}</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <Smartphone className="w-5 h-5 text-gray-600" />
            <div>
              <p className="text-sm text-gray-600">Device ID</p>
              <p className="font-mono text-xs text-gray-800 break-all">
                {deviceId.substring(0, 8)}...{deviceId.substring(deviceId.length - 8)}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="card p-1 mb-6">
        <div className="grid grid-cols-3 rounded-lg overflow-hidden">
          <button
            onClick={() => setActiveTab('data')}
            className={`py-3 px-4 text-center font-medium transition-all duration-200 ${
              activeTab === 'data'
                ? 'bg-gradient-to-r from-purple-600 to-blue-600 text-white shadow-lg'
                : 'text-gray-600 hover:text-gray-800 hover:bg-gray-50'
            }`}
          >
            Data Manager
          </button>
          <button
            onClick={() => setActiveTab('upload')}
            className={`py-3 px-4 text-center font-medium transition-all duration-200 ${
              activeTab === 'upload'
                ? 'bg-gradient-to-r from-purple-600 to-blue-600 text-white shadow-lg'
                : 'text-gray-600 hover:text-gray-800 hover:bg-gray-50'
            }`}
          >
            File Upload
          </button>
          <button
            onClick={() => setActiveTab('nfc')}
            className={`py-3 px-4 text-center font-medium transition-all duration-200 ${
              activeTab === 'nfc'
                ? 'bg-gradient-to-r from-purple-600 to-blue-600 text-white shadow-lg'
                : 'text-gray-600 hover:text-gray-800 hover:bg-gray-50'
            }`}
          >
            NFC Manager
          </button>
        </div>
      </div>

      {/* Tab Content */}
      <div className="space-y-6">
        {activeTab === 'data' && <DataManager />}
        {activeTab === 'upload' && <FileUpload />}
        {activeTab === 'nfc' && <NFCManager />}
      </div>
    </div>
  );
};

export default Dashboard;