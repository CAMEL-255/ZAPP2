import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useDevice } from '../context/DeviceContext';
import { dataService } from '../services/dataService';
import { DataItem, DataType } from '../types';
import { DATA_TYPES, getDataTypeConfig } from '../config/dataTypes';
import { Plus, Search, Filter, Eye, Edit, Trash2, Link, Copy, Check } from 'lucide-react';

const DataManager: React.FC = () => {
  const { user } = useAuth();
  const { deviceId } = useDevice();
  const [dataItems, setDataItems] = useState<DataItem[]>([]);
  const [filteredItems, setFilteredItems] = useState<DataItem[]>([]);
  const [selectedType, setSelectedType] = useState<DataType | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [loading, setLoading] = useState(true);
  const [copiedLink, setCopiedLink] = useState<string | null>(null);

  useEffect(() => {
    loadDataItems();
  }, [user]);

  useEffect(() => {
    filterItems();
  }, [dataItems, selectedType, searchQuery]);

  const loadDataItems = async () => {
    if (!user) return;
    
    try {
      const items = await dataService.getDataItems(user.id);
      setDataItems(items);
    } catch (error) {
      console.error('Error loading data items:', error);
    } finally {
      setLoading(false);
    }
  };

  const filterItems = () => {
    let filtered = dataItems;

    if (selectedType !== 'all') {
      filtered = filtered.filter(item => item.type === selectedType);
    }

    if (searchQuery) {
      filtered = filtered.filter(item =>
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (item.description && item.description.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }

    setFilteredItems(filtered);
  };

  const copyNFCLink = async (link: string) => {
    try {
      await navigator.clipboard.writeText(link);
      setCopiedLink(link);
      setTimeout(() => setCopiedLink(null), 2000);
    } catch (error) {
      console.error('Failed to copy link:', error);
    }
  };

  const deleteItem = async (id: string) => {
    if (!confirm('Are you sure you want to delete this item?')) return;
    
    try {
      await dataService.deleteDataItem(id);
      await loadDataItems();
    } catch (error) {
      console.error('Error deleting item:', error);
    }
  };

  const formatFileSize = (bytes?: number) => {
    if (!bytes) return 'N/A';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="text-gray-600">Loading your data...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="card p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-800">Data Manager</h2>
          <button
            onClick={() => setShowAddModal(true)}
            className="btn-primary flex items-center space-x-2"
          >
            <Plus className="w-4 h-4" />
            <span>Add Data</span>
          </button>
        </div>

        {/* Search and Filter */}
        <div className="space-y-4">
          <div className="relative">
            <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search your data..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="input-field w-full pl-10"
            />
          </div>

          <div className="flex items-center space-x-2 overflow-x-auto pb-2">
            <Filter className="w-5 h-5 text-gray-400 flex-shrink-0" />
            <button
              onClick={() => setSelectedType('all')}
              className={`px-3 py-1 rounded-full text-sm font-medium whitespace-nowrap ${
                selectedType === 'all'
                  ? 'bg-purple-100 text-purple-700'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              All ({dataItems.length})
            </button>
            {DATA_TYPES.map((type) => {
              const count = dataItems.filter(item => item.type === type.id).length;
              return (
                <button
                  key={type.id}
                  onClick={() => setSelectedType(type.id)}
                  className={`px-3 py-1 rounded-full text-sm font-medium whitespace-nowrap ${
                    selectedType === type.id
                      ? 'bg-purple-100 text-purple-700'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  {type.icon} {type.name} ({count})
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Data Items */}
      {filteredItems.length === 0 ? (
        <div className="card p-8 text-center">
          <div className="text-gray-400 mb-4">
            {dataItems.length === 0 ? (
              <>
                <Plus className="w-12 h-12 mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">No data items yet</h3>
                <p>Start by adding your first data item</p>
              </>
            ) : (
              <>
                <Search className="w-12 h-12 mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">No items found</h3>
                <p>Try adjusting your search or filter</p>
              </>
            )}
          </div>
          {dataItems.length === 0 && (
            <button
              onClick={() => setShowAddModal(true)}
              className="btn-primary"
            >
              Add Your First Item
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-4">
          {filteredItems.map((item) => {
            const typeConfig = getDataTypeConfig(item.type);
            return (
              <div key={item.id} className="card p-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-3 flex-1 min-w-0">
                    <div className={`w-10 h-10 rounded-lg ${typeConfig.color} flex items-center justify-center text-white text-lg flex-shrink-0`}>
                      {typeConfig.icon}
                    </div>
                    <div className="min-w-0 flex-1">
                      <h3 className="font-semibold text-gray-800 truncate">{item.name}</h3>
                      <p className="text-sm text-gray-600 mb-2">{typeConfig.name}</p>
                      {item.description && (
                        <p className="text-sm text-gray-500 mb-2">{item.description}</p>
                      )}
                      {item.fileName && (
                        <p className="text-xs text-gray-400">
                          {item.fileName} • {formatFileSize(item.fileSize)}
                        </p>
                      )}
                      <p className="text-xs text-gray-400 mt-1">
                        Created {new Date(item.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2 flex-shrink-0 ml-4">
                    <button
                      onClick={() => copyNFCLink(item.nfcLink)}
                      className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                      title="Copy NFC Link"
                    >
                      {copiedLink === item.nfcLink ? (
                        <Check className="w-4 h-4 text-green-600" />
                      ) : (
                        <Link className="w-4 h-4" />
                      )}
                    </button>
                    <button
                      onClick={() => deleteItem(item.id)}
                      className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      title="Delete"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* NFC Link Display */}
                <div className="mt-3 p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center justify-between">
                    <div className="min-w-0 flex-1">
                      <p className="text-xs text-gray-600 mb-1">NFC Link:</p>
                      <p className="text-sm font-mono text-gray-800 truncate">
                        {item.nfcLink}
                      </p>
                    </div>
                    <button
                      onClick={() => copyNFCLink(item.nfcLink)}
                      className="ml-2 p-1 text-gray-500 hover:text-gray-700"
                      title="Copy Link"
                    >
                      <Copy className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add Data Modal */}
      {showAddModal && (
        <AddDataModal
          onClose={() => setShowAddModal(false)}
          onSuccess={() => {
            setShowAddModal(false);
            loadDataItems();
          }}
        />
      )}
    </div>
  );
};

interface AddDataModalProps {
  onClose: () => void;
  onSuccess: () => void;
}

const AddDataModal: React.FC<AddDataModalProps> = ({ onClose, onSuccess }) => {
  const { user } = useAuth();
  const { deviceId } = useDevice();
  const [selectedType, setSelectedType] = useState<DataType>('id_card');
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !name.trim()) return;

    setLoading(true);
    try {
      let fileData, fileName, fileType, fileSize;
      
      if (file) {
        const reader = new FileReader();
        fileData = await new Promise<string>((resolve) => {
          reader.onload = (e) => resolve(e.target?.result as string);
          reader.readAsDataURL(file);
        });
        fileName = file.name;
        fileType = file.type;
        fileSize = file.size;
      }

      await dataService.createDataItem(
        user.id,
        deviceId,
        selectedType,
        name.trim(),
        description.trim() || undefined,
        fileData,
        fileName,
        fileType,
        fileSize
      );

      onSuccess();
    } catch (error) {
      console.error('Error creating data item:', error);
      alert('Error creating data item. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const typeConfig = getDataTypeConfig(selectedType);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="card w-full max-w-md max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Add New Data</h3>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Data Type Selection */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Data Type
              </label>
              <div className="grid grid-cols-2 gap-2">
                {DATA_TYPES.map((type) => (
                  <button
                    key={type.id}
                    type="button"
                    onClick={() => setSelectedType(type.id)}
                    className={`p-3 rounded-lg border-2 text-left transition-all ${
                      selectedType === type.id
                        ? 'border-purple-500 bg-purple-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="text-lg mb-1">{type.icon}</div>
                    <div className="text-sm font-medium">{type.name}</div>
                  </button>
                ))}
              </div>
              <p className="text-xs text-gray-500 mt-2">{typeConfig.description}</p>
            </div>

            {/* Name */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Name *
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="input-field w-full"
                placeholder={`Enter ${typeConfig.name.toLowerCase()} name`}
                required
              />
            </div>

            {/* Description */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Description
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="input-field w-full h-20 resize-none"
                placeholder="Optional description"
              />
            </div>

            {/* File Upload */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                File (Optional)
              </label>
              <input
                type="file"
                onChange={(e) => setFile(e.target.files?.[0] || null)}
                accept={typeConfig.acceptedFileTypes.join(',')}
                className="input-field w-full"
              />
              <p className="text-xs text-gray-500 mt-1">
                Accepted: {typeConfig.acceptedFileTypes.join(', ')}
              </p>
            </div>

            {/* Actions */}
            <div className="flex space-x-3 pt-4">
              <button
                type="button"
                onClick={onClose}
                className="btn-secondary flex-1"
                disabled={loading}
              >
                Cancel
              </button>
              <button
                type="submit"
                className="btn-primary flex-1"
                disabled={loading || !name.trim()}
              >
                {loading ? 'Creating...' : 'Create'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default DataManager;